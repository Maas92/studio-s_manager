import express from 'express';
const router = express.Router();

// Placeholder - implement similar to products
router.get('/', (req, res) => res.json({ data: { locations: [] } }));

export default router;